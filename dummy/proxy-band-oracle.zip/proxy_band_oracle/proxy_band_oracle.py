from iconservice import *

TAG = "Proxy Band Oracle"


class ProxyBandOracle(IconScoreBase):
    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._reference = DictDB('_reference', db, value_type=int)

    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()

    @external(readonly=True)
    def name(self) -> str:
        return f"Omm {TAG}"

    @external
    def set_reference_data(self, _base: str, _price: int) -> None:
        if self.msg.sender != self.owner:
            revert("NOT_AUTHORIZED")
        self._reference[_base] = _price

    @external(readonly=True)
    def get_reference_data(self, _base: str, _quote: str) -> dict:
        return {"rate": self._reference[_base]}
